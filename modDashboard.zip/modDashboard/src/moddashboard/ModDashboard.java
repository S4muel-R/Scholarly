/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package moddashboard;

import javax.swing.SwingUtilities;

/**
 *
 * @author sebas
 */
public class ModDashboard {
public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
        moddashboardclass dashboard = new moddashboardclass();
        dashboard.setVisible(true);
    });
}}

    
    

