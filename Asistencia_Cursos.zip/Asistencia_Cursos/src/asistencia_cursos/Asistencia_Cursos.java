package asistencia_cursos;
import java.util.Arrays;
import java.util.List;

public class Asistencia_Cursos {
    public static void main(String[] args) {
        Profesor prof = new Profesor("Laura");

        Curso cursoA = new Curso("Curso A");
        Estudiante adrian = new Estudiante("Adrian", "001");
        adrian.registrarAsistencia("Semana 1", "Ausente");
        adrian.registrarAsistencia("Semana 2", "Presente");
        cursoA.agregarEstudiante(adrian);
        cursoA.agregarEstudiante(new Estudiante("Maria", "002"));

        Curso cursoB = new Curso("Curso B");
        cursoB.agregarEstudiante(new Estudiante("Carlos", "003"));
        cursoB.agregarEstudiante(new Estudiante("Lucia", "004"));

        List<Curso> cursos = Arrays.asList(cursoA, cursoB);
        List<String> semanas = Arrays.asList("Semana 1", "Semana 2");

        AsistenciaManager.mostrarAsistenciaProfesor(prof, cursos, semanas);

        // Para que un estudiante vea su historial (ejemplo)
        // AsistenciaManager.mostrarHistorialEstudiante(adrian);
    }
}