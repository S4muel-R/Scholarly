package asistencia_cursos;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AsistenciaManager {

    public static void mostrarAsistenciaProfesor(Profesor prof, List<Curso> cursos, List<String> semanas) {
        JFrame frame = new JFrame("Asistencia - Profesor: " + prof.getNombre());
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Panel superior con selección de curso y semana
        JPanel seleccionPanel = new JPanel();

        JComboBox<String> cbCurso = new JComboBox<>();
        for (Curso c : cursos) {
            cbCurso.addItem(c.getNombre());
        }

        JComboBox<String> cbSemana = new JComboBox<>(semanas.toArray(new String[0]));

        seleccionPanel.add(new JLabel("Seleccionar curso:"));
        seleccionPanel.add(cbCurso);
        seleccionPanel.add(new JLabel("Seleccionar semana:"));
        seleccionPanel.add(cbSemana);

        // Panel con la lista de estudiantes y controles
        JPanel listaPanel = new JPanel();
        listaPanel.setLayout(new GridLayout(0, 3, 10, 10));

        // Función para cargar estudiantes según curso y semana seleccionados
        Runnable cargarEstudiantes = () -> {
            listaPanel.removeAll();
            String cursoSeleccionado = (String) cbCurso.getSelectedItem();
            String semanaSeleccionada = (String) cbSemana.getSelectedItem();

            Curso curso = null;
            for (Curso c : cursos) {
                if (c.getNombre().equals(cursoSeleccionado)) {
                    curso = c;
                    break;
                }
            }
            if (curso == null) return;

            for (Estudiante est : curso.getEstudiantes()) {
                listaPanel.add(new JLabel(est.getNombre()));

                JComboBox<String> estado = new JComboBox<>(new String[]{"Presente", "Ausente", "Justificado"});
                String actual = est.getHistorialAsistencia().getOrDefault(semanaSeleccionada, "Presente");
                estado.setSelectedItem(actual);
                listaPanel.add(estado);

                JButton guardar = new JButton("Guardar");
                guardar.addActionListener(ev -> {
                    est.registrarAsistencia(semanaSeleccionada, (String) estado.getSelectedItem());
                    JOptionPane.showMessageDialog(frame, "Asistencia guardada para " + est.getNombre());
                });
                listaPanel.add(guardar);
            }

            listaPanel.revalidate();
            listaPanel.repaint();
        };

        // Cargar estudiantes cuando cambie curso o semana
        cbCurso.addActionListener(e -> cargarEstudiantes.run());
        cbSemana.addActionListener(e -> cargarEstudiantes.run());

        // Añadir componentes al frame
        frame.add(seleccionPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(listaPanel), BorderLayout.CENTER);

        // Inicializar la carga
        cargarEstudiantes.run();

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public static void mostrarHistorialEstudiante(Estudiante est) {
        JFrame frame = new JFrame("Historial - Estudiante: " + est.getNombre());
        frame.setSize(300, 250);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTextArea area = new JTextArea();
        area.setEditable(false);

        StringBuilder sb = new StringBuilder("Historial de asistencia:\n");
        est.getHistorialAsistencia().forEach((sem, estd) -> sb.append(sem).append(": ").append(estd).append("\n"));

        area.setText(sb.toString());
        frame.add(new JScrollPane(area));

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}